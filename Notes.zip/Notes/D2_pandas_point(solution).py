#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#1)-데이터프레임-기초와-필터링" data-toc-modified-id="1)-데이터프레임-기초와-필터링-1">1) 데이터프레임 기초와 필터링</a></span></li><li><span><a href="#2)-요약" data-toc-modified-id="2)-요약-2">2) 요약</a></span></li><li><span><a href="#3)-파생변수-생성" data-toc-modified-id="3)-파생변수-생성-3">3) 파생변수 생성</a></span></li><li><span><a href="#4)-텍스트-데이터-처리" data-toc-modified-id="4)-텍스트-데이터-처리-4">4) 텍스트 데이터 처리</a></span></li><li><span><a href="#6)-Pivoting" data-toc-modified-id="6)-Pivoting-5">6) Pivoting</a></span></li><li><span><a href="#7)-데이터-병합" data-toc-modified-id="7)-데이터-병합-6">7) 데이터 병합</a></span></li><li><span><a href="#8)-기타" data-toc-modified-id="8)-기타-7">8) 기타</a></span></li></ul></div>

# Q. 데이터프레임을 다루는 패키지를 불러오자

# In[1]:


import pandas as pd


# # 1) 데이터프레임 기초와 필터링

# - DataFrame 색인 `.colname vs ['colname']`

# In[2]:


dict(a=[1,2,3], shape=[7,34,1])


# In[25]:


df=pd.DataFrame(dict(a=[1,2,3], shape=[7,34,1]))
df


# In[26]:


df['a']


# In[27]:


df.a


# In[28]:


df['shape']


# In[29]:


df.shape


# - DataFrame의 변수명 확인 및 변경

# In[30]:


df.columns.values[0] = 'b'


# In[31]:


df


# > 버그있어서 반영이 안되는 경우도 있다!

# In[32]:


df=df.rename(columns={'shape':'c'})
df


# - Pandas 객체 필터링  `loc vs. iloc`  
#     - file: `krx_202105_utf8.csv`
#     - Purely integer-location based indexing for selection by position. `iloc`

# In[33]:


df


# In[34]:


df.loc[1:]


# In[35]:


df.iloc[1:]


# > 똑같아 보이죠? 내부 작동은 다르다!

# In[40]:


df.index = [11,12,13]
df


# In[41]:


df.loc[11:]


# In[42]:


df.iloc[11:]


# > loc는 인덱스 이름 기준으로 작동! iloc는 인덱스 순서로 작동
# 

# In[23]:


df.loc[0]


# In[145]:


df.iloc[0]


# - 인덱스가 꼬여 있는 경우

# In[58]:


df=pd.DataFrame(dict(val=[1,2,3,6]),index=[-3,-1,-1,-4])
df


# In[59]:


df.loc[:-1]


# > 인덱스 이름 기준으로 앞 인덱스들 가져온다

# In[60]:


df.iloc[:-1]


# In[ ]:


df


# In[61]:


df.iloc[1:]


# > 바로 마지막 인덱스 순서 제외하고 나온다 df.iloc[1:] vs. df.iloc[:-1]

# In[63]:


df=pd.DataFrame(dict(val=[1,2,3]),index=['가','나','다'])
df


# In[70]:


df.iloc[:-1]


# In[69]:


df.iloc[-1]


# In[78]:


df.loc[-1]


# In[ ]:


df.loc['다']


# > -1 의 사용에 따라 의미가 다름   
# `iloc`
# 슬라이싱[:-1] 할 때는 -1번째 행부터 앞행까지 뜻함
# 인덱싱[-1] 할 때는 제일 끝을 뜻함
#   
# > `loc`
# 는 인덱싱할 때도 인덱스 이름에 없으면 나오지 않음

# In[148]:


df.reset_index()


# In[150]:


df=df.reset_index(drop=True)
df


# ---

# Q. `krx_202105_utf8.csv` 을 불러오자

# In[ ]:


import os
os.getcwd()


# In[3]:


df_krx = pd.read_csv('../Datasets/krx_202105_utf8.csv')
df_krx.head(2)


# Q. 단순회귀(독립 `시가`, 종속 `종가` ) 문제에서 독립변수를 함수에 넣을 때 올바른 방법은?
# `df_krx['시가'] vs. df_krx[['시가']]`

# In[4]:


df_krx['시가'].shape


# In[5]:


df_krx[['시가']].shape


# > 패키지 마다 다른데 shape 에러 나면 shape에 맞게 바꿔주면 됨

# Q. `지수명` 변수의 원소가 `KRX 300`이거나 `KRX 반도체`인 행을 추출하여 df_krx300_krxban 객체에 저장하시오.

# In[4]:


df_krx300_krxban =df_krx.loc[df_krx['지수명'].isin(['KRX 300','KRX 반도체'])]
df_krx300_krxban.head(2)


# Q. df_krx300_krxban 객체에서 `거래대금`이 가장 큰 `지수명`은?

# In[27]:


df_krx300_krxban.loc[df_krx300_krxban['거래대금']==df_krx300_krxban['거래대금'].max(), '지수명']


# In[6]:


df_krx300_krxban.loc[464]


# - 데이터 정렬 `sort`

# Q. df_krx에서 20210527 에 거래된 지수 중 거래대금이 큰 순으로 5개 추출하면?

# In[44]:


df_krx[df_krx.날짜==20210527].sort_values(by='거래대금', ascending=False)[:5]


# - 결측치 처리 `isna` `fillna`  
#     - file: `iris_missing.csv` 

# Q. `iris_missing.csv` 을 불러오자

# In[17]:


df_iris = pd.read_csv('../Datasets/iris_missing.csv')
df_iris.head(2)


# In[9]:


df_iris.isna()


# Q. setosa기준으로 Sepal.Width 평균으로 Sepal.Width na값을 대체하여라

# In[18]:


mean_setosa_sepal_width=df_iris.loc[df_iris.Species=='setosa', 'Sepal.Width'].mean()
mean_setosa_sepal_width


# In[19]:


df_iris.loc[(df_iris.Species=='setosa') , 'Sepal.Width'].head(2)


# In[20]:


df_iris.loc[(df_iris.Species=='setosa') , 'Sepal.Width'].fillna(mean_setosa_sepal_width)[:2]


# In[21]:


df_iris.loc[(df_iris.Species=='setosa') , 'Sepal.Width'] = df_iris.loc[(df_iris.Species=='setosa') , 'Sepal.Width'].fillna(mean_setosa_sepal_width)


# Q. isna를 사용하여 위의 결과를 그대로 반영하는 코드를 작성하시오

# In[77]:


df_iris.loc[(df_iris.Species=='setosa') & (df_iris['Sepal.Width'].isna()), 'Sepal.Width']=mean_setosa_sepal_width


# In[78]:


df_iris


# In[84]:


df_iris.fillna('')
# Q. 결측치, 공백을 제거하시오 


# In[ ]:





# # 2) 요약 
# - file:`bike_sharing.csv`, `diamonds.csv`

# - 원소 개수 확인 `unique` `value_counts` `crosstab`

# In[3]:


df_bike = pd.read_csv('../Datasets/bike_sharing.csv')
df_bike[:5]


# In[87]:


df_bike['season'].unique()


# In[89]:


df_bike['season'].nunique()


# In[90]:


df_bike['season'].value_counts()


# In[4]:


df_bike['season'].value_counts(normalize=True).round(3)


# In[ ]:





# Q. weather 와 season 간의 관계는? 혹시 weather의 특정 번호가 비(rain)이면 season이 2에서 많이 나타나지 않을까? 확인해보자

# > weather이 뭔지 모르지만 weather을 추측해보자

# In[26]:


pd.crosstab(df_bike['weather'], df_bike['season'],margins=True,).round(4)


# > weather가 4계절에서 골고루 나타난다. 어느나라 데이터인지 모르기 때문에 여름이라고 비가 많이 올 것이라고 판단하는 것을 지양해야 한다.

# - 1: Clear, Few clouds, Partly cloudy, Partly cloudy
# - 2: Mist + Cloudy, Mist + Broken clouds, Mist + Few clouds, Mist
# - 3: Light Snow, Light Rain + Thunderstorm + Scattered clouds, Light Rain + Scattered clouds
# - 4: Heavy Rain + Ice Pallets + Thunderstorm + Mist, Snow + Fog

#  - 그룹화 `groupby`

# Q. diamonds 데이터를 가져와서 cut을 기준으로 그룹화를 한 후 가격에 대한 'min','mean','median'를 구한 후 median기준으로 오름차순이 되게 하세요

# In[10]:


df_diamond = pd.read_csv('../Datasets/diamonds.csv')
df_diamond.head(3)


# In[163]:


df_diamond.groupby('cut')['price'].agg(['min','mean','median']).sort_values(by='median')


# # 3) 파생변수 생성
# - file:`bike_sharing.csv`

# In[182]:


df_bike.head(2)


# Q. 월별로 자전거 대여횟수의 증감을 나타내라, 가능하다면 그래프로 시각화 하여라
# - casual: 미등록회원 대여횟수
# - registered: 등록회원 대여횟수

# In[29]:


df_bike.info()


# In[30]:


df_bike['datetime'] = pd.to_datetime(df_bike['datetime'])


# In[31]:


df_bike['datetime'].info()


# In[32]:


df_bike['month']=df_bike['datetime'].dt.month


# In[33]:


df_bike.head()


# In[34]:


df_bike.tail()


# In[90]:


df_bike_month_trend=df_bike.groupby('month')['count'].sum()


# In[87]:


df_bike_month_trend


# In[88]:


import matplotlib.pyplot as plt


# In[89]:


plt.plot(df_bike_month);


# In[ ]:


df_bike_month_trend.plot()


# # 4) 텍스트 데이터 처리

# In[35]:


df_krx.지수명.unique()


# Q. 지수명이 `KRX 300` 을 포함하는 데이터만 가져오라

# In[52]:


df_krx.loc[df_krx.지수명.str.contains('KRX 300'),'지수명'].unique()


# Q. 지수명이 `KRX 300`, `KRX 자동차` 을 포함하는 데이터만 가져오라

# In[53]:


df_krx[df_krx.지수명.str.contains('KRX 300|KRX 자동차')]['지수명'].unique()


# In[54]:


df_krx[df_krx.지수명.str.contains('KRX 300| KRX 자동차')]['지수명'].unique()


# > 'KRX 자동차' 가 없어지죠?ㅡ

# In[55]:


df_krx[df_krx.지수명.str.contains('KRX 300|KRX 자동차')]['지수명'].nunique()


# In[56]:


df_krx[df_krx.지수명.str.contains('KRX 300| KRX 자동차')]['지수명'].nunique()


# > 주의! `|` 다음에 띄어쓰기 하면 안됨. 

# Q. diamond데이터에서 cut이 `Good` 을 포함하는 행만 가져오라

# In[234]:


df_diamond['cut'].unique()


# In[17]:


df_diamond.loc[df_diamond['cut'].str.contains('Good'), 'cut'].unique()


# In[19]:


df_diamond.loc[df_diamond['cut'].isin(['Good']), 'cut'].unique()


# > isin는 동등비교를 합니다. 
# 'Good' == 'Good', 'Good' != 'very Good',   
# 
# > contains는 내부글자들의 비교를 합니다.
# 'Good'이란 글자가 있는지 없는지
# 그래서 Good이란 very Good이 출력이 됩니다. 

# # 6) Pivoting

# - melt  
# file: `weather.csv`
# > 컬럼을 녹여서 행으로 보낸다

# In[6]:


df_weather = pd.read_csv('../Datasets/weather.csv')
df_weather.head()


# Q. berlin, chicago 의 일별 날씨 흐름을 차트로 표현하고 싶다. (melt 이용)

# In[345]:


df_weather_melt_day=df_weather.melt(id_vars='day', value_name='temp')
df_weather_melt_day


# In[342]:


#시험에 그래프 그려라는 없어서 추이 확인할 땐 아래 쉬운 코드를 사용하세요.
import matplotlib.pyplot as plt
figure,axes = plt.subplots()

for cityname in ['chicago','berlin']:
    axes.plot(df_weather_melt_day.loc[df_weather_melt_day['variable']==cityname,'day'],             df_weather_melt_day.loc[df_weather_melt_day['variable']==cityname,'temp']  ,label=cityname)

axes.set_xlabel("cityname")
axes.set_ylabel("temp")
axes.legend(loc='best');


# In[341]:


df_weather


# In[340]:


plt.plot(df_weather['day'], df_weather['chicago'])
plt.plot(df_weather['day'], df_weather['berlin']);


# > 더 간단히도 할 수 있다.

# # 7) 데이터 병합

# - concat

# In[353]:


train, test=df_weather[:3], df_weather[3:]


# In[357]:


dataset = pd.concat([test, test])
dataset


# - merge
# `vlookup`
# - 테이블이 분리되어 있는 경우
#     - ex) 보안수준

# In[3]:


d1 = {'Name': ['장준규', '홍길동', '운영자'], 'ID': [1, 2, 3], 'Country': ['India', 'India', 'USA'],
      'Role': ['CEO', 'CTO', 'CTO']}
df1 = pd.DataFrame(d1)
df1


# In[4]:


df2 = pd.DataFrame({'ID': [1, 2, 3, 4], 'Security_Level': ['VIP1', 'VIP2', 'VIP2','VIP3']})
df2 


# In[8]:


df_merge=pd.merge(left=df1, right=df2, how='left', on='ID')
df_merge


# In[ ]:





# # 8) 기타

# - lambda

# Q. df_merge 에서 'CTO' 이면 1 아니면 0 인 'is_CTO' 컬럼을 사용자 정의 함수를 이용하여 작성하시오

# In[376]:


def is_CTO(x):
    if x=='CTO':
        return 1
    else:
        return 0


# In[378]:


df_merge['is_CTO']=df_merge['Role'].map(is_CTO)
df_merge


# Q. 위 문제를 lambda를 사용해서 작성하시오

# In[ ]:


df_merge['Role'].map(lambda x: 1 if x=='CTO' else 0)


# - 정규표현식 regular expression

# In[61]:


import re

pattern = re.compile("01[0-9]{1}-[0-9]{4}-[0-9]{4}")

text = '마동석씨의 핸드폰 번호는 010-1234-5678 입니다 홍길동씨의 핸드폰 번호는 010-4567-5678 입니다 마동석씨의 핸드폰 번호는 010-1234-5678 입니다'

pattern.findall(text)


# In[ ]:




