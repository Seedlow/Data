#!/usr/bin/env python
# coding: utf-8

# In[162]:


import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error


# In[76]:


df_origin = pd.read_csv('../Datasets/mobiles.csv')


# # 문제1

# In[77]:


df1 = df_origin.copy()
df1.head(2)


# In[78]:


df1 = df1.assign(perf = df1.ROM/32 + df1.RAM/2 + df1.num_rear_camera + df1.num_front_camera + df1.battery_capacity/1000,)


# In[79]:


df1


# In[80]:


df1_salse_mean = df1['sales'].mean()
df1_salse_mean


# In[81]:


df1_salse_sqrt = df1['sales'].std()
df1_salse_sqrt


# In[82]:


df1_hot = df1.loc[df1['sales'] > df1_salse_mean + df1_salse_sqrt*2]


# In[83]:


df1_hot


# In[84]:


round(df1_hot['perf'].mean(),2)


# ## Solution

# In[85]:


df1_s = df_origin.copy()


# In[86]:


df1_s.columns


# In[87]:


df1_s = df1_s[['ROM','RAM','num_rear_camera','num_front_camera','battery_capacity','sales']]
df1_s.head(5)


# In[89]:


idx = df1_s['ROM']/32 + df1_s['RAM']/2 + df1_s['num_rear_camera'] + df1_s['num_front_camera'] + df1_s['battery_capacity']/1000)


# # 문제2

# In[11]:


df2 = df_origin.copy()


# In[12]:


df2_col = ['battery_capacity','ratings','num_of_ratings','sales_price','discount_percent','sales']


# In[13]:


df2 = df2.loc[df2['num_rear_camera'] > 1]
df2_corr = df2[df2_col].corr().abs()


# In[14]:


round(df2_corr.apply(lambda x:x.replace(1,0)).max(),2)


# ## Solution

# In[92]:


df2_s = df_origin.copy ()


# In[93]:


df2_s.columns


# In[94]:


df2_s = df2_s.loc[df2_s.num_rear_camera != 1]


# In[97]:


df2_s = df2_s.loc[:,'battery_capacity':]
df2_s.columns


# In[102]:


round(df2_s.corr()['sales'][:-1].abs().max(),2)


# # 문제3
# kNN 알고리즘을 사용, 이웃의 개수를 변화하면서 가장 성능이 좋은 모델 찾기
# RMSE(Root Mean Squeared Error)를 기준으로 가장 성능이 좋은 모델을 확인하고 해당 모델의 k(군집 개수)를 구하라.

# In[16]:


df3 = df_origin.copy()


# In[17]:


df3.head(5)


# In[ ]:


# X_train, X_test, y_train, y_test = train_test_split()


# In[29]:


#pd.get_dummies(data = train, columns = ['Embarked'], prefix = 'Embarked')
X = pd.get_dummies(data = df3, columns=['screen_size']).drop(columns='sales')
X.head(2)
X.info()


# In[32]:


y = df3['sales']
y


# In[33]:


X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.2, random_state=123)


# In[39]:


scaler_mm = MinMaxScaler()


# In[42]:


X_train = scaler_mm.fit_transform(X_train).copy()
X_test=scaler_mm.transform(X_test)


# In[50]:


for X in (3,5,7,9,11):
    model_kn = KNeighborsRegressor(n_neighbors=X)
    model_kn.fit(X_train,y_train)
    print(model_kn.score(X_test,y_test))


# ## Solution

# In[105]:


df3_s = df_origin.copy()


# In[107]:


seed = 123


# In[113]:


X = df3_s.drop(columns='sales').copy()


# In[114]:


y = df3_s['sales'].copy()


# In[115]:


X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=seed)


# In[116]:


df3_s.info()


# In[121]:


col_cate = X_train.select_dtypes(exclude='number').columns
col_cate


# In[119]:


col_num = X_train.select_dtypes(include='number').columns


# In[122]:


col_num


# In[140]:


scaler_mm = MinMaxScaler()


# In[141]:


X_train_num = scaler_mm.fit_transform(X_train[col_num])
X_test_num = scaler_mm.transform(X_test[col_num])


# ※ 명목형 독립변수의 경우 One Hot Encoding을 실시한 결과

# In[142]:


from sklearn.preprocessing import OneHotEncoder
ohe = OneHotEncoder(handle_unknown='ignore',sparse_output=True)


# In[143]:


X_train_cate = ohe.fit_transform(X_train[col_cate])
X_test_cate = ohe.transform(X_test[col_cate])


# In[144]:


X_train_cate


# In[145]:


num_depend = X_test_cate.shape[1] + X_train_num.shape[1]


# In[146]:


assert num_depend == 14


# In[150]:


from scipy import sparse


# In[153]:


X_train = sparse.hstack([X_train_cate, X_train_num])
X_test = sparse.hstack([X_test_cate, X_test_num])


# In[154]:


X_train


# In[155]:


X_test


# In[169]:


score = {}
for X in [3,5,7,9,11]:
    model_knnr = KNeighborsRegressor(n_neighbors=X)
    model_knnr.fit(X=X_train,y=y_train)
    y_pred = model_knnr.predict(X_test)
    score[X] = mean_squared_error(y_test,y_pred)**0.5


# In[172]:


score.items( )


# Q. Dict 정렬하기

# In[175]:


sorted(score.items(), key=lambda x:x[1])[0]


# In[178]:


df_result = pd.DataFrame(index = score.keys(), data = score.values(), columns=['MSE'])
df_result


# In[179]:


df_result.sort_values(by='MSE').idxmin()


# # Solution2  (Get_dummy)

# In[208]:


df3_s = df_origin.copy()
df_dum = pd.get_dummies(df3_s)


# In[209]:


df_dum


# In[214]:


y = df_dum['sales'].copy()
X = df_dum.drop(columns='sales').copy()


# In[211]:


scores = {}
for X in [3,5,7,9,11]:
    model_knnr = KNeighborsRegressor(n_neighbors=X)
    model_knnr.fit(X,y)
    y_pred = model_knnr.predict(X)
    scores[X] = mean_squared_error(y,y_pred)


# In[215]:


sorted(scores.items(), key=lambda x:x[1])[0]


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




