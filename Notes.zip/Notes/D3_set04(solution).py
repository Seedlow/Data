#!/usr/bin/env python
# coding: utf-8

# > 2번 카테고리 선정 설명해야해 
# 카테고리1=제조 국가, 카테고리2=제조사, 뭐 이런 걸로 생각하면 된다. 
# 아니면 식품류-유제품-치즈-> 상품의 다양성  
# ex) A고객의 데이터 식품류.유제품.치즈, 식품류.유제품.우유, 식품류.유제품.우유 -> 2개 카테고리 구입

# 디지털프라자 A지점에서 최근 연휴 직전에 재고 처리와 매출 신장을 위해 대대적인 할인 행사를 하였다. 하루만 반짝 진행한 행사에서 예상보다 많은 손님이 방문했고 이번에 발생한 매출데이터를 취합하여 향후 발송할 판촉물에 들어갈 컨텐츠를 기획하고자 한다. 취합한 데이터는 다음과 같다.

# In[3]:


from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score


# In[4]:


import pandas as pd
df_origin = pd.read_csv("../Datasets/sales_pos.csv")
df_origin.head(2)


# ### Q1. 매출액이 가장 큰 상품을 확인하고 해당 상품을 가장 많이 구매하는 직업을 확인하시오.
# ※ 분석 결과를 기반으로 job 변수의 번호를 최종 출력하시오.  
# (정답 예시: 1)

# In[5]:


df1 = df_origin.copy()


# In[6]:


df1 = df1[["job", "prod", "purchase"]].copy()
df1.head(2)


# Q. prod가 중복되면 prod별로 매출액의 합을 봐야할 듯, 확인해보자

# In[7]:


df1['prod'].value_counts()


# > 그룹바이 써야겠네

# In[8]:


df1.groupby('prod')['purchase'].sum().idxmax()


# !주의

# In[9]:


df1.groupby('prod')['purchase'].sum().sort_values(ascending=False).idxmax()


# > sort_values 꼭 하고 해야 한다. idxmax 할 때 중복으로 가장 높은 데이터가 있으면 첫번째 인덱스만 가져온다

# In[10]:


pd.Series(index=['a','b','c'], data=[1,4,4])


# In[11]:


pd.Series(index=['a','b','c'], data=[1,4,4]).idxmax()


# ---

# In[12]:


str_prod_high=df1.groupby('prod')['purchase'].sum().sort_values(ascending=False).idxmax()


# In[13]:


df1.loc[df1['prod']==str_prod_high, 'job']


# In[14]:


df1.loc[df1['prod']==str_prod_high, 'job'].value_counts()


# In[15]:


df1.loc[df1['prod']==str_prod_high, 'job'].value_counts(ascending=False).idxmax()


# In[ ]:


# df1.groupby('job')['purchase'].sum().idxmax()


# ### A. 4

# ### Q2. 결혼 여부(marital)에 따라 구매하는 물품의 종류가 많이 차이 나는지 확인하고자 한다. 비교적 신혼부부가 많은 26-35세 그룹을 대상으로 각 고객의 구매물품 카테고리 개수를 산출하고 결혼여부별로 그 평균값의 차이를 산출하시오.
# ※ 구매 물품의 카테고리 개수 산출에는 prod_cat1, prod_cat2, prod_cat3 변수를 사용한다.  
# ※ 카테고리 관련 변수의 결측치는 0으로 대치한다.  
# ※ 결측치를 대치한 데이터까지 포함하여 문제를 풀이하시오.  
# ※ 카테고리 관련 변수의 처리 예시는 다음과 같다.  
# <div style='width:300px;'>
#     
# ![image-4.png](attachment:image-4.png)
#     
# </div>
#     
# ※ 고객 식별자가 1인 고객은 총 21개 카테고리의 물품을 구매하였다.  
# ※ 정답은 절대값을 반올림하여 소수점 둘째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[94]:


df2 = df_origin.copy()


# In[95]:


df2.head(2)


# ※ 카테고리 관련 변수의 결측치는 0으로 대치한다.  

# ※ 결측치를 대치한 데이터까지 포함하여 문제를 풀이하시오.  

# In[96]:


col_derive=['prod_cat1','prod_cat2','prod_cat3']


# In[97]:


df2[col_derive]=df2[col_derive].fillna(0)


# In[98]:


df2.head(2)


# 
# ※ 구매 물품의 카테고리 개수 산출에는 prod_cat1, prod_cat2, prod_cat3 변수를 사용한다.  

# In[99]:


df2[col_derive].apply(lambda s:s.astype('str')).sum(axis=1)


# In[100]:


df2['unique_cate']=df2[col_derive].apply(lambda s:s.astype('str')).sum(axis=1)


# ※ 고객 식별자가 1인 고객은 총 21개 카테고리의 물품을 구매하였다.  

# In[101]:


df2.loc[df2['user']==1, 'unique_cate']


# In[102]:


df2.loc[df2['user']==1, 'unique_cate'].nunique()


# 비교적 신혼부부가 많은 26-35세 그룹을 대상으로 각 고객의 구매물품 카테고리 개수를 산출하고 결혼여부별로 그 평균값의 차이를 산출하시오.  
# ※ 정답은 절대값을 반올림하여 소수점 둘째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[103]:


df2.head(2)


# In[104]:


df2.age_group.unique()


# In[105]:


df2 = df2.loc[df2.age_group=='26-35']


# In[106]:


df2.groupby(['user','marital'])['unique_cate'].nunique()


# > 어차피 결혼여부는 하나니깐 groupby에 넣어도 괜찮음, 아니면 merge 해도 됨, 답 구하고 merge로도 해보겠습니다

# In[28]:


s_groupby=df2.groupby(['user','marital'])['unique_cate'].nunique()


# In[109]:


s_groupby.head()


# In[30]:


s_groupby.groupby('marital').mean()


# In[31]:


s_groupby.groupby('marital').mean().diff().abs().round(2)


# ### A. 0.13

# - merge로 하는 거 

# In[87]:


s_user=df2.groupby('user')['unique_cate'].nunique()
s_user


# In[89]:


df2[['user','marital']]


# In[92]:


df_user_drop_duplicate=df2[['user','marital']].drop_duplicates()
df_user_drop_duplicate


# In[88]:


df_merge=pd.merge(left=s_user, right=df_user_drop_duplicate, left_index=True, right_on='user', how='left')
df_merge


# In[33]:


df_merge.groupby('marital')['unique_cate'].agg(['mean']).diff().abs().round(2)


# ### Q3. 고객을 군집화 하여 각 군집별로 마케팅 전략을 수립하고자 한다. 다음에 제시된 변수를 대상으로 k-means 군집분석을 실시하고 7개 군집으로 분석했을 때 Silhouette score 를 산출하시오.
# <독립 변수>
#  - 구매 상품 종류
#  - 성별
#  - 나이
#  - 직업 
#  - 도시
#  - 결혼 여부
#  - 총 구매금액
# 
# ※ 구매 상품 종류 변수는 "prod" 변수를 참고하여 생성하시오.  
# ※ 성별 변수는 "gender" 변수에서 "M"을 1, "F"를 0으로 변환하여 사용하시오.  
# ※ 나이는 "age_group" 변수에서 나이가 가장 적은 그룹을 0으로 지정하고 가장 나이가 많은 그룹은 6으로 지정하는 방식으로 순서형 변수로 변환하시오.  
# ※ 직업과 도시 변수는 One Hot Encoding 변환하여 사용하시오.  
# ※ 군집 분석에 사용되는 변수는 총 29개이며 MinMax 정규화 후 분석하시오.  
# ※ seed는 123으로 지정하시오.  
# ※ 결과는 반올림하여 소수점 둘째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[34]:


df3 = df_origin.copy()
df3.head(2)


# ※ seed는 123으로 지정하시오.  
# 7개 군집으로 분석했을 때

# In[35]:


#params
k, seed = 7, 123


# 고객별이니깐!!!!!!!!!!!!!!!!!!! 고객 기준으로 한 행에 한 사람이 나와야 된다. 고객 기준 중복되는 데이터를 일단 없애자.

# In[36]:


df3=df3.drop(columns=col_derive)


# In[37]:


df3['user'].nunique()


# > 5891 유저에 대해 df를 만들어야 한다

# In[38]:


df3[df3.user==1]


# > prod 랑 purchase 컬럼 빼고 다 똑같아 보이네 확인해보자

# In[39]:


df_user=df3.drop(columns=['prod','purchase']).drop_duplicates()


# In[40]:


df_user


# > 5891 맞네

# ※ 성별 변수는 "gender" 변수에서 "M"을 1, "F"를 0으로 변환하여 사용하시오.  
# ※ 나이는 "age_group" 변수에서 나이가 가장 적은 그룹을 0으로 지정하고 가장 나이가 많은 그룹은 6으로 지정하는 방식으로 순서형 변수로 변환하시오.  

# In[41]:


df_user['gender']=df_user['gender'].replace({'M':1, 'F':0})


# In[42]:


df_user['age_group'].unique()


# In[43]:


dict_age=dict(pd.Series([0, 6, 2, 4, 5, 3, 1], index=df_user['age_group'].unique() ))


# In[44]:


dict_age


# In[45]:


df_user['age_group']=df_user['age_group'].replace(dict_age)


# ※ 직업과 도시 변수는 One Hot Encoding 변환하여 사용하시오.  

# In[46]:


df_user.columns


# In[47]:


pd.get_dummies(df_user)


# > 엥 job은 안됐네 get dummies가 dtype보고 결정함

# In[48]:


df_user.info()


# In[49]:


df_user['job']=df_user['job'].astype('str')


# In[50]:


df_user=pd.get_dummies(df_user)


# ※ 구매 상품 종류 변수는 "prod" 변수를 참고하여 생성하시오.  

# In[51]:


s_prod_nunique=df3.groupby('user')['prod'].nunique()


# In[52]:


s_prod_nunique


# In[53]:


df_user


# In[54]:


df_user=df_user.merge(s_prod_nunique, how='left', right_index=True, left_on='user')


# 독립변수 총 구매금액

# In[55]:


s_sum_purchase = df3.groupby('user')['purchase'].sum()


# In[56]:


s_sum_purchase


# In[57]:


df_user=df_user.merge(s_sum_purchase,  how='left', right_index = True, left_on='user')


# In[58]:


df_user


# ※ 군집 분석에 사용되는 변수는 총 29개이며 MinMax 정규화 후 분석하시오.  

# In[59]:


df_user=df_user.drop(columns='user')


# In[60]:


scaler_mm = MinMaxScaler()


# In[61]:


df_user=scaler_mm.fit_transform(df_user)


# k-means 군집분석을 실시하고 7개 군집으로 분석했을 때 Silhouette score 를 산출하시오.  
# ※ 결과는 반올림하여 소수점 둘째 자리까지 출력하시오.    
# (정답 예시: 0.12)

# In[62]:


model_kmeans=KMeans(n_clusters=k, random_state=seed)


# In[63]:


model_kmeans.fit(df_user)


# In[64]:


model_kmeans.labels_


# In[65]:


silhouette_score(df_user, model_kmeans.labels_)


# In[66]:


round(silhouette_score(df_user, model_kmeans.labels_), 2)

