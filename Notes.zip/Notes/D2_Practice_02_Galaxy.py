#!/usr/bin/env python
# coding: utf-8

# In[8]:


import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score


# In[10]:


df_origin = pd.read_csv('../Datasets/galaxy_users.csv')
df_origin.head(4)


# # 문제 1

# In[19]:


df1 = df_origin.copy()


# In[20]:


col_cate = ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies']
col_cate


# In[45]:


df1_1 = df1[col_cate].copy()
df1_1


# > 'No internet service' 가 엉뚱한 값이다

# In[235]:


df1_1_drop = df1_1.loc[(df1_1.apply(lambda x:x.str.contains('No internet service')).sum(axis=1)==0)]
df1_1_drop.head(20)


# In[236]:


df1_1_drop['ServiceCount'] = df1_1_drop[col_cate].apply(lambda x:x.str.contains('Yes')).sum(axis=1)
df1_1_drop.loc[df1_1_drop['ServiceCount'] == 1]


# In[237]:


df1_1_drop.loc[df1_1_drop['ServiceCount'] == 6]


# In[238]:


round(966/284,1)


# In[165]:


# Solution


# In[175]:


df1_s = df_origin.copy()
df1_s[col_cate].apply(lambda x:x.unique())


# In[181]:


df1_s = df1_s.loc[~(df1_s[col_cate].apply(lambda x:x=='No internet service').sum(axis=1)>=1)]


# In[190]:


df1_s_yes_no = df1_s[col_cate].apply(lambda x:x.replace({'Yes':1,'No':0}))
s_n_of_services = df1_s_yes_no.sum(axis=1)


# In[202]:


n1 = s_n_of_services[s_n_of_services == 1].sum()


# In[201]:


n2 = s_n_of_services[s_n_of_services == 6].shape[0]


# In[203]:


round(n1/n2,1)


# # 문제 2

# In[141]:


df2 = df_origin.copy()
df2.head(2)


# In[242]:


df2['UsedMonth'] = df2['TotalCharges'] // df2['MonthlyCharges']
df2['UsedMonth']
df2.head(2)


# In[243]:


df2_col=['tenure','MonthlyCharges','UsedMonth']
df2_1 = df2[df2_col].copy()
df2_1


# In[244]:


round(df2_1.corr(method='pearson'),3)


# In[206]:


#solution


# In[208]:


df2_s = df_origin.copy()


# In[214]:


df2_s = df2_s[['tenure','MonthlyCharges','TotalCharges']]
df2_s = df2_s.assign(Monthly_user = df2.TotalCharges//df2.MonthlyCharges).drop(columns='TotalCharges')


# In[217]:


round(df2_s.corr(),3).abs()


# In[219]:


round(df2_s.corr()['tenure'][1:],3)


# # 문제3

# In[313]:


df3 = df_origin.copy()


# In[314]:


df3


# In[315]:


df3_col = ['SeniorCitizen',
'Partner',
'Dependents',
'tenure',
'MonthlyCharges',
'TotalCharges',
'OnlineSecurity',
'OnlineBackup',
'DeviceProtection',
'TechSupport',
'StreamingTV',
'StreamingMovies',
'PaperlessBilling']


# In[316]:


seed = 123
X=df3[df3_col].copy()
y=df3['Churn'].copy()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=seed)


# In[317]:


def groups(x):
    if x == 'Yes':
        return 1
    elif x == 'No':
        return 0
    else:
        return -1


# In[318]:


df3[df3_col].applymap(groups)


# In[319]:


X_train = X_train.applymap(groups).copy()
X_test = X_test.applymap(groups).copy()


# In[320]:


X_train.info()


# In[321]:


scaler_mm = MinMaxScaler()


# In[322]:


X_train=scaler_mm.fit_transform(X_train)
X_test=scaler_mm.transform(X_test)


# In[323]:


model_lr = LogisticRegression(random_state = seed)
model_lr.fit(X = X_train,
             y = y_train)


# In[324]:


y_pred=model_lr.predict(X_test)


# In[325]:


from sklearn.metrics import confusion_matrix
confusion_matrix(y_test, y_pred)


# In[304]:


#Q. 재현율(민감도)를 구하라
72/(554+72)


# In[326]:


round(f1_score(y_test, y_pred, pos_label='Yes'),2)


# In[327]:


from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))


# In[ ]:





# X_test
