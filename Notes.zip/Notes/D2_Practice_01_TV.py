#!/usr/bin/env python
# coding: utf-8

# In[118]:


from sklearn.ensemble import RandomForestRegressor
import pandas as pd
df_origin = pd.read_csv("../Datasets/TV.csv")


# In[119]:


df = df_origin.copy()


# # 문제1 주사율 60Hz TV 갯수 

# In[48]:


df1 = df.loc[df.Frequency.str.contains('60 Hz')|df.Picture_qualtiy.str.contains('60 Hz')|df.Speaker.str.contains('60 Hz')]
df1.info()


# In[120]:


# Solution  -----------------------------------------
df1_s = df[['Picture_qualtiy','Speaker','Frequency']].copy()
df1_s


# In[121]:


df1_s['Picture_qualtiy'].map(lambda x:'Hz' in x).sum()


# In[122]:


df1_s.apply(lambda s:s.str.contains('Hz')).sum(axis=0)


# In[123]:


df1_s.apply(lambda s:s.str.contains('Hz')).sum(axis=1)


# In[125]:


df1_s[df1_s.apply(lambda x:x.str.contains('Hz')).sum(axis=1) == 0]


# In[130]:


df1_s_drop = df1_s.loc[~(df1_s.apply(lambda x:x.str.contains('Hz')).sum(axis=1) == 0)]


# In[131]:


df1_s_drop.apply(lambda x:x.str.contains("60 Hz")).sum(axis=1).value_counts()


# # 문제2 해상도

# In[43]:


df2 = df.loc[df.Operating_system.str.contains('HD|4K|8K')|df.Picture_qualtiy.str.contains('HD|4K|8K')|df.channel.str.contains('HD|4K|8K')]
df2_8K = df.loc[df.Operating_system.str.contains('8K')|df.Picture_qualtiy.str.contains('8K')|df.channel.str.contains('8K')]
df2_4K = df.loc[df.Operating_system.str.contains('4K')|df.Picture_qualtiy.str.contains('4K')|df.channel.str.contains('4K')]


# In[44]:


df2_8K


# In[45]:


df2_4K


# In[87]:


df2_4K['Stars'].mean()


# In[88]:


(df2_8K['Stars'] - df2_4K['Stars'].mean()).abs()


# In[89]:


df.head(2)


# In[225]:


# solution -----------------------------
df2_s = df[['channel','Operating_system','Picture_qualtiy']].copy()
col_cate = ['channel','Operating_system','Picture_qualtiy']
df2_s


# In[227]:


df2_s['is_4K'] = df2_s[col_cate].apply(lambda s:s.str.contains('4K')).sum(axis=1)
df2_s['is_8K'] = df2_s[col_cate].apply(lambda s:s.str.contains('8K')).sum(axis=1)


# In[161]:


df2_s_w_stars = pd.concat([df2_s[['is_4K','is_8K']], df_origin['Stars']], axis =1)
df2_s_w_stars


# In[165]:


mean_4k = df2_s_w_stars.loc[df2_s_w_stars.is_4K == 1, 'Stars'].mean()


# In[166]:


mean_8k = df2_s_w_stars.loc[df2_s_w_stars.is_8K == 1, 'Stars'].mean()


# In[172]:


round(mean_8k - mean_4k, 2)


# # 문제3 해상도

# In[174]:


df3 = df_origin.copy()
df3.head(2)


# In[175]:


df3['discount'] = df3['current_price'] / df3['MRP']
df3.head(2)


# In[179]:


# drop 하기
df3 = df3.loc[~(df3['channel'].str.contains('Pixels|Oper'))]


# In[184]:


df3['channel'].str.contains('Netflix').astype(int)


# In[191]:


df3 = df3.assign(support_netflix = df3['channel'].str.contains('Netflix').astype(int),
          support_prime = df3['channel'].str.contains('Prime Video').astype(int))


# In[197]:


df3 =  df3.assign(review_ratio = df3.Reviews/df3.Ratings,
          discount_rae = df3.current_price / df3.MRP,
           is_high = df3.Picture_qualtiy.str.contains('4K|8K').astype(int))


# In[199]:


df3 = df3.rename(columns={'discount_rae':'discount_rate'})
df3


# In[201]:


col_feature = {'support_netflix','support_prime','review_ratio','discount_rate','is_high','MRP'}


# In[203]:


df3[col_feature].apply(lambda x:x.isna().sum())


# In[205]:


df3[col_feature].isna().sum()


# In[207]:


df3_notna = df3.loc[~df3.review_ratio.isna()]


# In[208]:


df3_notna.shape


# In[211]:


model_rfr = RandomForestRegressor(random_state=123)


# In[214]:


model_rfr.fit(X=df3_notna[col_feature],
              y=df3_notna['Stars'])


# In[216]:


model_rfr.feature_importances_


# In[218]:


model_rfr.feature_names_in_


# In[223]:


pd.Series(index=model_rfr.feature_names_in_, data=model_rfr.feature_importances_).sort_values(ascending=False).idxmax()


# # A3. 할인율
