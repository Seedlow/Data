#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier


# In[21]:


df_raw = pd.read_csv('../Datasets/edu_enrollees.csv')


# In[22]:


df_raw = df_raw.drop(['city','company_size','company_type'],axis=1)


# In[23]:


df_raw = df_raw.dropna()


# In[24]:


#df_raw = df_raw[(df_raw['experience'] != '>20') & (df_raw['experience'] != '<1')]
df_raw = df_raw.loc[~(df_raw['experience'].isin([">20","<1"]))]


# In[25]:


df_raw['experience'] = df_raw['experience'].astype('int')


# In[37]:


# df_raw = df_raw[(df_raw['last_new_job'] != '>4') & (df_raw['last_new_job'] != 'never')]
df_raw = df_raw.loc[~(df_raw['last_new_job'].isin([">4","never"]))]


# In[38]:


df_raw['last_new_job'] = df_raw['last_new_job'].astype('int')


# In[39]:


df_raw.info()


# In[40]:


df_origin = df_raw.copy()


# # 문제 1

# In[41]:


df1 = df_origin.copy()


# In[33]:


df1


# In[34]:


df1['relevant_experience'].value_counts()


# In[35]:


df1.groupby('relevant_experience').sum()


# target total : 541 + 1319
# B - Has relevant experience -> 1319 / 6109
# A - No relevant experience -> 541 / 1413

# In[43]:


A = 541 / 1413
B = 1319 / 6109
round(A/B,2)


# # 문제 2

# In[44]:


df2 = df_origin.copy()


# In[46]:


# params
C = 100000
ramdom_state = 123
solver = 'liblinear'
max_iter = 1000


# In[47]:


df2.columns


# In[ ]:


df2


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




