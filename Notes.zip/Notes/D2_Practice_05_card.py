#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.tree import DecisionTreeRegressor


# In[26]:


df_origin = pd.read_csv('../Datasets/card_cust.csv')
df_origin.head()
df_origin['CREDIT_LIMIT'] = df_origin['CREDIT_LIMIT'].fillna(df_origin['CREDIT_LIMIT'].mean())
df_origin['MINIMUM_PAYMENTS'] = df_origin['MINIMUM_PAYMENTS'].fillna(df_origin['MINIMUM_PAYMENTS'].mean())


# # 문제 1

# In[29]:


df1 = df_origin.copy()
df_origin.columns


# 연간 평균 잔고액 BALANCE
# 
# 신용카드 서비스 이용기간 TENURE
# 
# 간의 관계를 파악하여 신용카드 한도 CREDIT_LIMIT 조정에 근거 자료로 활용

# In[30]:


df1_cat = ['BALANCE', 'TENURE', 'CREDIT_LIMIT']


# In[32]:


df1_cut = df1[df1_cat]


# In[34]:


round(df1_cut.groupby('TENURE').corr(),2)


# > A.  TENURE = 7.0  일 때, 0.95

# In[163]:


round(df1_cut.groupby('TENURE').corr(),2).unstack()['BALANCE']['CREDIT_LIMIT'].max()


# # Solution

# In[154]:


df1_s = df_origin.copy()


# In[156]:


df1_s[['BALANCE','CREDIT_LIMIT']].corr()


# In[158]:


ls_corr=[]
for n in df1['TENURE'].unique():
    _df = df1_s.loc[df1_s['TENURE']==n,['BALANCE','CREDIT_LIMIT']]
    _stat_corr = _df.corr().iloc[0,1]
    ls_corr.append(_stat_corr)


# In[160]:


max(ls_corr).round(2)


# # 문제 2

# In[35]:


df2 = df_origin.copy()


# In[38]:


df2.info()


# In[50]:


df2_drop = df2.drop('CUST_ID',axis=1)


# In[51]:


df2_drop.info()


# In[52]:


zscaler = StandardScaler()


# In[58]:


df2_std = zscaler.fit_transform(df2_drop)


# In[67]:


seed = 1234
for k in [2,3,4,5]:
    model_kmeans = KMeans(n_clusters=k,random_state=seed)
    model_kmeans.fit(df2_std)
    print(round(silhouette_score(df2_std,model_kmeans.labels_),2))


# > k=2 일 때, 제일 높군

# In[68]:


model_kmeans = KMeans(n_clusters=2,random_state=seed)
model_kmeans.fit(df2_std)


# In[80]:


pred = model_kmeans.predict(df2_std)
df2_drop['clust'] = pred
df2_drop


# In[83]:


df2_drop.groupby('clust')['ONEOFF_PURCHASES'].mean().round(2)


# > A.  3946.19

# # Solution

# In[164]:


#params
seed = 1234


# In[177]:


df2_s = df_origin.copy()


# In[178]:


s_cust_id = df2_s.pop('CUST_ID')


# In[179]:


scaler_sd = StandardScaler()


# In[187]:


df2_s_std = scaler_sd.fit_transform(df2_s)


# In[188]:


lst_scores = []
for k in range(2,6):
    model_kmeans = KMeans(n_clusters=k,random_state=seed)
    model_kmeans.fit(df2_s_std)
    score_sub = silhouette_score(df2_s_std,model_kmeans.labels_)
    lst_scores.append(score_sub)


# In[189]:


lst_scores


# In[193]:


pd.Series(lst_scores,index = range(2,6))


# In[195]:


best_k = 2


# In[196]:


model_kmeans = KMeans(n_clusters=best_k,random_state=seed)
model_kmeans.fit(df2_s_std)


# In[198]:


df2_s['cluster'] = model_kmeans.labels_


# In[202]:


df2_s.groupby('cluster')['ONEOFF_PURCHASES'].mean()


# # 문제 3

# In[203]:


df3 = df_origin.copy()


# In[109]:


X_train = df3[(df3['CUST_ID'] % 4) != 0]


# In[110]:


X_test = df3[(df3['CUST_ID'] % 4) == 0]


# In[111]:


X_train


# In[119]:


X_train_feature = X_train.drop({'CUST_ID','ONEOFF_PURCHASES'},axis=1)


# In[120]:


X_train_target = X_train['ONEOFF_PURCHASES']


# In[121]:


X_test_feature =  X_test.drop({'CUST_ID','ONEOFF_PURCHASES'},axis=1)


# In[122]:


X_test_targe = X_test['ONEOFF_PURCHASES']


# In[216]:


model = DecisionTreeRegressor(random_state=seed)


# In[217]:


model.fit(X_train_feature,X_train_target)


# In[218]:


y_pred = model.predict(X_test_feature)


# In[219]:


((((X_test_targe-y_pred)**2).sum())/248)**0.5


# > # Solution

# In[204]:


df3 = df_origin.copy()


# In[207]:


seed = 1234
df_test = df3.loc[df3['CUST_ID']%4 == 0]
df_train = df3.loc[df3['CUST_ID']%4 != 0]


# In[211]:


len(df_test),len(df_train)


# In[ ]:





# In[212]:


y_train = df_train.pop('ONEOFF_PURCHASES')
y_test = df_test.pop('ONEOFF_PURCHASES')


# In[214]:


X_train = df_train.drop('CUST_ID',axis =1)
X_test = df_test.drop(columns='CUST_ID')


# In[215]:


model_dtr = DecisionTreeRegressor(random_state=seed)


# In[220]:


model_dtr.fit(X=X_train, y=y_train)


# In[221]:


y_pred = model_dtr.predict(X_test)


# In[223]:


round((((y_test - y_pred)**2).mean())**0.5,1)


# In[224]:


from sklearn.metrics import mean_squared_error


# In[228]:


round(mean_squared_error(y_test,y_pred)**0.5,1)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




