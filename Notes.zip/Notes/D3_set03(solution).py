#!/usr/bin/env python
# coding: utf-8

# > Q3  ※ 정답은 반올림하여 소수점 둘째 자리까지 출력하시오.   <- 삭제

# 갓 입사한 신입사원 김모씨는 기획 부서에 배치되었다. 첫 프로젝트로 신규 스마트폰 스팩 기획 업무를 보조하게 되었다. 장고 끝에 김씨는 온라인 디지털 마켓 사이트 "디판다요"에서 판매중인 스마트폰 데이터를 수집하여 이를 분석하고 향후 프로젝트의 백데이터로 활용하기로 결심하였다.

# In[1]:


from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error
import pandas as pd


# In[2]:


import pandas as pd
df_origin = pd.read_csv("../Datasets/mobiles.csv")
df_origin.head(2)


# ### Q1. 스마트폰의 경우 많은 제품이 출시되지만 정작 주목받는 제품은 극히 적다고 한다. 판매 지수(sales)를 기준으로 이상치라고 판단되는 제품을 주목받는 제품이라고 판단하고 해당 제품들의 성능지표를 산출하시오. 산출된 성능지표의 평균은 얼마인가?
# 
# <성능지표 계산식>
# $$성능지표 = \frac{ROM}{32} + \frac{RAM}{2} + 카메라 개수 + \frac{배터리 용량}{1000}$$
# 
# ※ 카메라 개수  : num_rear_camera + num_front_camera  
# ※ 이상치는 평균으로 부터 2 표준편차보다 큰 값으로 정의한다.  
# ※ 결과는 반올림하여 소수점 둘째 자리까지 계산하시오.  
# (정답 예시: 0.12) 

# In[3]:


df1 = df_origin.copy()


# ---

# 판매 지수(sales)를 기준으로 이상치  
# ※ 이상치는 평균으로 부터 2 표준편차보다 큰 값으로 정의한다.  

# In[4]:


df1=df1[["ROM", "RAM", "num_rear_camera", "num_front_camera", "battery_capacity", "sales"]].copy()


# Q. sales 어떻게 생겼길래 아웃라이어 처리하라는 거지?

# In[5]:


df1['sales'].hist();


# > 400 이상인 애들이 보이네

# In[6]:


stat_outlier=df1['sales'].mean() +  df1['sales'].std()*2
stat_outlier


# 이상치라고 판단되는 제품을 주목받는 제품이라고 판단하고 해당 제품들의 성능지표

# In[7]:


df1=df1.loc[df1['sales']>stat_outlier]


# 성능지표  
# <성능지표 계산식>
# $$성능지표 = \frac{ROM}{32} + \frac{RAM}{2} + 카메라 개수 + \frac{배터리 용량}{1000}$$
#  
# ※ 카메라 개수  : num_rear_camera + num_front_camera  
# 

# In[8]:


idx = (df1["ROM"] / 32) + (df1["RAM"] / 2)                     + df1["num_front_camera"] + df1["num_rear_camera"]                     + (df1["battery_capacity"] / 1000)


# ※ 결과는 반올림하여 소수점 둘째 자리까지 계산하시오.  

# In[9]:


idx


# In[10]:


round(idx.mean(), 2)


# ### Q2. 판매 지수와 가장 상관관계가 높은 변수를 찾고자 한다. 배터리 용량, 평가 점수 평균, 평가 개수, 판매 가격, 할인율 변수와 판매 지수를 피어슨 상관분석을 실시하였을 때 상관계수의 절대값이 가장 큰 변수의 상관계수는 얼마인가?
# ※ 후면 카메라가 1개인 제품은 제외하시오.  
# ※ 통계적 유의성은 고려하지 않음  
# ※ 결과는 반올림하여 소수점 둘째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[11]:


df2 = df_origin.copy()


# ※ 후면 카메라가 1개인 제품은 제외하시오.  

# In[12]:


df2.columns


# In[13]:


df2=df2.loc[df2.num_rear_camera!=1]


# 판매 지수와 가장 상관관계가 높은 변수
# 배터리 용량, 평가 점수 평균, 평가 개수, 판매 가격, 할인율 변수와 판매 지수
# 
# 절대값 가장 큰 거

# ※ 결과는 반올림하여 소수점 둘째 자리까지 출력하시오.  

# In[14]:


df2=df2.loc[:, 'battery_capacity':]


# In[15]:


df2.corr()['sales'][:-1].abs().max()


# In[16]:


round(df2.corr()['sales'][:-1].abs().max(), 2)


# ### Q3. 판매지수를 예측하기 위해 머신러닝 모델을 활용하고자 한다. k-NN 알고리즘을 사용하고 연산에 사용하는 이웃의 개수를 변화하면서 가장 성능이 좋은 모델을 확보하려 한다. RMSE(Root Mean Squared Error)를 기준으로 가장 성능이 좋은 모델의 군집개수 k를 구하라
# 
# <독립 변수>
# - 판매 지수를 제외한 모든 변수
# 
# <종속변수>
#  - 판매 지수
# 
# ※ 명목형 독립변수의 경우 One Hot Encoding을 실시한 결과를 모델에 사용하시오.  
# ※ 학습에 사용하는 독립변수의 개수는 총 14개 이다.  
# ※ 학습 및 평가 데이터 세트 분할비는 8:2으로 하시오.  
# ※ 정규화는 Min-Max 정규화를 실시하며 평가 데이터 세트는 학습 데이터 세트 기반으로 정규화 하시오.  
# ※ seed는 123으로 고정하시오.  
# ※ 최근접 이웃은 3, 5, 7, 9, 11개를 사용하시오.  
# (정답 예시: 9)

# In[17]:


df3= df_origin.copy()


# ※ seed는 123으로 고정하시오.  

# In[18]:


seed = 123


# ※ 학습 및 평가 데이터 세트 분할비는 8:2으로 하시오.  

# In[19]:


X=df3.drop(columns='sales').copy()
y=df3['sales'].copy()


# In[20]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=seed)


# ※ 정규화는 Min-Max 정규화를 실시하며 평가 데이터 세트는 학습 데이터 세트 기반으로 정규화 하시오.  

# In[21]:


df3.info()


# In[22]:


col_cate = X_train.select_dtypes(exclude='number').columns
col_num = X_train.select_dtypes(include='number').columns


# In[23]:


scaler_mm=MinMaxScaler()


# In[24]:


X_train_num = scaler_mm.fit_transform(X_train[col_num])
X_test_num = scaler_mm.transform(X_test[col_num])


# In[25]:


# y도 스케일링 해도 괜찮다 어차피 모델 간 성능 비교를 rmse로 성능판단을 할 거니깐 
# X_test_num = minmax_scaler.transform(pd.concat([X_test[col_num], y_test], axis=1))
# y_test_minmax=X_test_num[:,-1]
# X_test_num=X_test_num[:,:-1]


# ※ 명목형 독립변수의 경우 One Hot Encoding을 실시한 결과를 모델에 사용하시오.  

# In[26]:


from sklearn.preprocessing import OneHotEncoder


# In[27]:


ohe=OneHotEncoder(handle_unknown='ignore', sparse_output=True)


# > 지금은 테스트셋이 하나의 데이터셋에서 나눴는데 만약 테스트셋을 따로 제공했을 때 테스트셋의 범주형 컬럼개수가 더 많다면 판다스 겟더미함수는 오류발생

# In[28]:


X_train_cate = ohe.fit_transform(X_train[col_cate])
X_test_cate = ohe.transform(X_test[col_cate])


# In[29]:


X_train_cate


# > 희소행렬(Sparse Matrix, 0이 너무 많은 행렬)을 Dense Matrix(우리가 일반적으로 보고 있는 테이블형태)하게 저장할 필요없이 메모리 효율적으로 숫자가 있는 위치만 저장함)
# 
# > 지금은 카테고리가 컬럼하나 밖에 없고 그 컬럼의 유니크 범주가 몇 개 없어서 사용할 필요는 없다.

# ※ 학습에 사용하는 독립변수의 개수는 총 14개 이다.  

# In[30]:


num_depend = X_train_cate.shape[1]+X_train_num.shape[1]


# In[31]:


assert num_depend == 14


# - 데이터 합치기

# In[32]:


from scipy import sparse


# In[33]:


X_train=sparse.hstack([X_train_cate, X_train_num])
X_test=sparse.hstack([X_test_cate, X_test_num])


# ※ 최근접 이웃은 3, 5, 7, 9, 11개를 사용하시오.  

# In[34]:


k_values = [3,5,7,9,11]


# RMSE(Root Mean Squared Error)를 기준 k를 구하라

# - 3으로 일단 테스트 보여드릴게요

# In[35]:


model_knnr=KNeighborsRegressor(n_neighbors=k_values[0])


# In[36]:


model_knnr.fit(X=X_train,y=y_train)


# Q. 모델이 일반적인으로 말하는 학습을 했을까요? 안했을까요?

# > A. KNN은 instance based model! test들어오기 전까지 대기! lazy learner!

# In[37]:


y_pred = model_knnr.predict(X_test)


# In[38]:


mean_squared_error(y_test,y_pred)


# - 반복문 잠깐

# In[39]:


for k in k_values:
    print(k)


# In[40]:


for k in k_values:
    model_knnr=KNeighborsRegressor(n_neighbors=k)
    print(model_knnr.n_neighbors)


# In[41]:


scores = {}
for k in k_values:
    model_knnr=KNeighborsRegressor(n_neighbors=k)
    model_knnr.fit(X_train,y_train)
    y_pred=model_knnr.predict(X_test)
    scores[k] = mean_squared_error(y_test, y_pred)


# In[42]:


scores


# Q. 딕셔너리 정렬하시오

# In[44]:


sorted(scores.items(), key=lambda x:x[1])[0]
# sorted(scores.items(), key=lambda x:x[1], reverse=True)


# In[74]:


pd.DataFrame(index=scores.keys(), data=scores.values(), columns=['MSE']).sort_values(by='MSE').idxmin()


# ---

# - train과 test가 하나의 데이터셋에서 분리할 경우, k값을 구한다고 하면 문제 빨리 풀기

# In[45]:


df_dum=pd.get_dummies(df3)


# In[46]:


y=df_dum['sales']
X=df_dum.drop(columns='sales').copy()


# In[47]:


scores = {}
for k in k_values:
    model_knnr=KNeighborsRegressor(n_neighbors=k)
    model_knnr.fit(X,y)
    y_pred=model_knnr.predict(X)
    scores[k]=mean_squared_error(y, y_pred)
scores


# In[48]:


sorted(scores.items(),  key=lambda x:x[1])[0]

