#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score


# In[2]:


df_origin = pd.read_csv('../Datasets/sales_pos.csv')


# In[3]:


df_origin.head()


# # 문제 1

# In[115]:


df1 = df_origin.copy()


# In[114]:


df1.groupby(df1['prod']).sum().sort_values(by='purchase')


# In[ ]:


# P00025442  27995166


# In[34]:


#df1.loc(df1['prod']=='P00025442')
#df1.loc(df1['prod'].apply(lambda x:x=='P00025442'))
#df1.loc(df1['prod'] == 'P00025442')
df1_max_pur = df1[df1['prod'] == 'P00025442']
df1_max_pur.head(5)


# In[38]:


df1_max_pur.groupby('job').sum().sort_values(by='purchase')


# A. 4

# # Solution

# In[118]:


df1 = df_origin.copy()
df1 = df1[['job','prod','purchase']]
df1


# In[122]:


#df1.groupby('prod')['purchase'].sum().sort_values(ascending=False).idxmax()
df1.groupby('prod')['purchase'].sum().sort_values(ascending=False)


# In[132]:


str_prod_high = df1.groupby('prod')['purchase'].sum().sort_values(ascending=False).idxmax()
str_prod_high


# In[134]:


df1.loc[df1['prod']==str_prod_high,'job']


# In[135]:


df1.loc[df1['prod']==str_prod_high,'job'].value_counts().idxmax()


# In[ ]:





# # 문제 2

# In[52]:


df2 = df_origin.copy()


# In[77]:


df2['prod_cat1'] = df2['prod_cat1'].fillna(0)
df2['prod_cat1'].unique()


# In[89]:


df2['prod_cat2'] = df2['prod_cat2'].fillna(0)
df2['prod_cat2'] = df2['prod_cat2'].astype(int)
df2['prod_cat2'].unique()


# In[90]:


df2['prod_cat3'] = df2['prod_cat3'].fillna(0)
df2['prod_cat3'] = df2['prod_cat3'].astype(int)
df2['prod_cat3'].unique()


# In[93]:


df2['prod_cat'] = df2['prod_cat1'].astype(str) + '-' + df2['prod_cat2'].astype(str) + '-' + df2['prod_cat3'].astype(str)
df2


# In[97]:


df2_n = df2.loc[df2['age_group'] == '26-35']
df2_n


# In[111]:


df2_n_n = df2_n[{'user','prod','marital','prod_cat'}]
df2_n_n


# In[166]:


df2_n_n.groupby(['user','marital']).nunique()


# # Solution

# In[143]:


df2 = df_origin.copy()
df2.head()


# In[144]:


col_derive = ['prod_cat1','prod_cat2','prod_cat3']
df2[col_derive] = df2[col_derive].fillna(0)
df2.head()


# In[148]:


df2['unique_cate'] = df2[col_derive].apply(lambda x:x.astype('str')).sum(axis=1)


# In[150]:


df2


# In[153]:


df2.loc[df2['user']==1,'unique_cate'].nunique()


# In[154]:


df2.age_group.unique()


# In[156]:


df2 = df2.loc[df2.age_group == '26-35']


# 1) groupby 방법

# In[158]:


s_groupby = df2.groupby(['user','marital'])['unique_cate'].nunique()


# In[165]:


round(abs(s_groupby.groupby('marital').mean().diff()[1]),2)


# 2) merge 방법

# In[169]:


s_user = df2.groupby('user')['unique_cate'].nunique()


# In[172]:


df_user_drop_duplicate = df2[['user','marital']].drop_duplicates()


# In[177]:


df_merge = pd.merge(left=s_user,right=df_user_drop_duplicate,how='left', left_index=True,right_on='user')


# In[180]:


df_merge.groupby('marital')['unique_cate'].mean().diff().abs().round(2)


# In[184]:


df_merge.groupby('marital')['unique_cate'].agg(['mean']).diff().abs().round(2)


# # 문제 3

# # Solution

# In[255]:


df3 = df_origin.copy()


# In[256]:


#params
k,seed = 7,123


# In[257]:


col_derive = ['prod_cat1','prod_cat2','prod_cat3']
df3=df3.drop(columns=col_derive)


# In[258]:


df_user = df3.drop(columns=['prod','purchase']).drop_duplicates()


# In[259]:


df_user


# In[260]:


df_user['gender'] = df_user['gender'].replace({'M':1,'F':0})


# In[261]:


df_user['age_group'].unique()


# In[262]:


dict_age = pd.Series([0,6,2,4,5,3,1],index = df_user['age_group'].unique())
dict_age


# In[263]:


df_user['age_group'] = df_user['age_group'].replace(dict_age)


# In[264]:


df_user


# 직업과 도시변수 One Hot Encoding 변환

# In[265]:


df_user.columns


# In[266]:


df_user['job'] = df_user['job'].astype('str')


# In[268]:


df_user = pd.get_dummies(df_user)


# In[269]:


s_prod_nunique = df3.groupby('user')['prod'].nunique()


# In[271]:


df_user = df_user.merge(s_prod_nunique,how='left',left_on='user',right_index=True)
df_user


# In[272]:


s_sum_purchase = df3.groupby('user')['purchase'].sum()


# In[273]:


df_user = df_user.merge(s_sum_purchase,how='left',left_on='user',right_index = True)


# In[274]:


df_user.shape


# 군집 분석에 사용되는 변수는 총 29개이며 minMax정규화 후 분서갛시ㅗ

# In[278]:


df_user.shape


# In[280]:


df_user = df_user.drop('user',axis=1)
df_user


# In[282]:


scaler_mm = MinMaxScaler()
df_user = scaler_mm.fit_transform(df_user)


# k-means군잡 분석하고 7개 군집

# In[283]:


model_kmeans = KMeans(n_clusters=k,random_state=seed)


# In[284]:


model_kmeans.fit(df_user)


# In[285]:


model_kmeans.labels_


# In[287]:


df_user.shape


# In[292]:


round(silhouette_score(df_user,model_kmeans.labels_),2)


# In[ ]:





# In[ ]:





# In[ ]:




