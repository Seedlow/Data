#!/usr/bin/env python
# coding: utf-8

# 디지털 기기 취급 전문업체 DigiSales는 오프라인 매장에서 갤럭시 제품군을 구매한 이력이 있는 사람들의 단말기 이용 행태를 분석하기 위해 통신사 MT로 부터 익명화 처리된 고객 정보를 일부 구매하였다. 해당 데이터에서 인사이트를 뽑기 위해 다양한 분석을 해보고자 한다.

# In[3]:


import pandas as pd
df_origin = pd.read_csv("../Datasets/galaxy_users.csv")
df_origin.head(2)


# ### Q1. 부가 서비스를 많이 사용할수록 제품 또는 브랜드에 고관여 되어있다는 가설을 세우고 분석을 하고자 한다. 이에 앞서 고객별 부가서비스 사용 현황 통계를 산출 하고자 한다. 부가 서비스를 1개 사용하는 사람은 부가 서비스를 6개 사용하는 사람 보다 몇 배나 많은지 계산하시오.
# 
# ※ 부가서비스 대상 변수: OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies  
# ※ 부가서비스 변수의 범주가 "Yes"인 경우 1로 "No"는 0으로 간주한다.  
# ※ 부가서비스 변수에 "Yes" 또는 "No"가 아닌 다른 범주가 있는 경우 해당 행은 제거 후 분석하시오.  
# ※ 첫 번째 고객(7590-VHVEG)의 경우 부가서비스는 1개 이용 중이다.  
# ※ 정답은 반올림하여 소수점 첫째 자리까지 출력하시오.  
# (정답 예시: 1.2)

# In[2]:


df1 = df_origin.copy()


# In[3]:


df1.shape


# ※ 부가서비스 대상 변수: OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies
# 

# In[28]:


col_service = ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies']


# In[29]:


df1[col_service].head(1)


# ※ 부가서비스 변수에 "Yes" 또는 "No"가 아닌 다른 범주가 있는 경우 해당 행은 제거 후 분석하시오

# In[30]:


df1[col_service].apply(lambda x: x.unique())


# In[38]:


(df1[col_service].apply(lambda x: x=='No internet service').sum(axis=1)>=1).sum()


# In[31]:


to_be_deleted_no_internet=df1[col_service].apply(lambda x: x=='No internet service').sum(axis=1)>=1


# In[32]:


to_be_deleted_no_internet


# In[39]:


df1=df1.loc[~to_be_deleted_no_internet,]


# In[40]:


df1.shape


# ※ 첫 번째 고객(7590-VHVEG)의 경우 부가서비스는 1개 이용 중이다.  

# In[41]:


df1.head(2)


# In[2]:


# df1[col_service].iloc[0]


# ※ 부가서비스 변수의 범주가 "Yes"인 경우 1로 "No"는 0으로 간주한다.

# In[42]:


get_ipython().run_line_magic('who', '')


# > 갑자기 colname으로 했던 변수명이 생각이 안날 때 유용

# In[43]:


df1_yes_no=df1[col_service].apply(lambda x: x.replace({'Yes': 1, 'No': 0}))
df1_yes_no.head(2)


# 부가 서비스를 1개 사용하는 사람은 부가 서비스를 6개 사용하는 사람 보다 몇 배나 많은지 계산하시오.

# In[44]:


df1_yes_no.sum(axis=1)


# In[46]:


s_n_of_services=df1_yes_no.sum(axis=1)


# - 부가 서비스 1개

# In[49]:


n_1 = s_n_of_services[s_n_of_services==1].sum()
n_1


# - 부가 서비스 6개

# In[13]:


n_6 = s_n_of_services[s_n_of_services==6].shape[0]
n_6


# > 얘는 다 더하면 안되니깐 행의 개수로 부가 서비스 개수를 판단

# ※ 정답은 반올림하여 소수점 첫째 자리까지 출력하시오.
# (정답 예시: 1.2)

# In[14]:


round(n_1/n_6, 1)


# ### A1. 3.4

# ---

# ### Q2. 여러 변수간 상관관계를 확인하고자 한다. 현 직장 근속 월수, 월별 청구 금액, 통신사 사용 월수간 피어슨 상관분석을 실시하고 그 결과 중 상관계수 절대값이 가장 높은 것을 확인하시오. 
# ※ 통신사 사용 월수는 총 청구금액을 월별 청구금액으로 나눈 값의 몫으로 한다.  
# ※ 본 문제 풀이에 계약 갱신 주기(Contract)는 관련없음  
# ※ 정답은 반올림하여 소수점 셋째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[4]:


df2 = df_origin.copy()


# In[5]:


df2.head(2)


# ※ 통신사 사용 월수는 총 청구금액을 월별 청구금액으로 나눈 값의 몫으로 한다.

# Q. 똑같은 사용자가 있으면 월별 청구금액(MonthlyCharges)를 더 해서 처리해야할까? 일단 똑같은 사용자가 여러행에 존재하는지 보자

# In[7]:


df2['customerID'].unique().shape, len(df2)


# > 없네 바로 파생변수 만들면 되겠다ㅡ

# In[8]:


df2=df2[['tenure', 'MonthlyCharges', 'TotalCharges']].copy()


# In[10]:


df2_add_monthly_used=df2.assign(Monthly_used=df2.TotalCharges//df2.MonthlyCharges).drop(columns='TotalCharges')


# In[12]:


round(df2_add_monthly_used.corr(), 3)['tenure'][1:]


# ### A. 0.999

# ---

# ### Q3. 고객 이탈여부를 종속변수로 하는 모델을 만들어보고자 한다. 데이터 분할 후 정규화를 실시하여 로지스틱 회귀분석을 실시하고 해당 모델을 기준점 삼아 모델을 개선하고자 한다. 주어진 독립변수를 활용하여 F1-score로 모델을 평가하시오.
# 
# <독립변수>
#  - 시니어 여부  SeniorCitizen
#  - 배우자 존재 여부 Partner
#  - 부양가족 존재 여부 Dependents
#  - 현 직장 근속 개월 수 tenure
#  - 월별 청구 금액 MonthlyCharges
#  - 누적 청구 금액 TotalCharges
#  - 온라인 보안 서비스 OnlineSecurity
#  - 온라인 백업 서비스 OnlineBackup
#  - 기기 보호 서비스 DeviceProtection
#  - 기술 지원 서비스 TechSupport
#  - 영화 스트리밍 서비스 StreamingTV
#  - 온라인 명세서 발급 서비스 PaperlessBilling
#  
# <종속변수>
#  - 고객 이탈여부 Churn
# 
# ※ 범주형 변수의 범주가 "Yes"인 경우 1로, "No"인 경우 0으로 치환하여 분석하시오.  
# ※ 범주형 변수에서 "Yes"와 "No"가 아닌 나머지 범주는 -1로 치환하시오.  
# ※ 학습 및 평가 데이터 세트 분할비는 7:3으로 하시오.  
# ※ 정규화는 Min-Max 정규화를 실시하며 모든 변수를 대상으로 하시오.  
# ※ 평가 데이터 세트는 학습 데이터 세트 기반으로 정규화 하시오.  
# ※ seed는 123으로 고정하시오.  
# ※ 정답은 반올림하여 소수점 둘째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[4]:


df3= df_origin.copy()


# In[5]:


text = '''시니어 여부 SeniorCitizen
배우자 존재 여부 Partner
부양가족 존재 여부 Dependents
현 직장 근속 개월 수 tenure
월별 청구 금액 MonthlyCharges
누적 청구 금액 TotalCharges
온라인 보안 서비스 OnlineSecurity
온라인 백업 서비스 OnlineBackup
기기 보호 서비스 DeviceProtection
기술 지원 서비스 TechSupport
영화 스트리밍 서비스 StreamingTV
온라인 명세서 발급 서비스 PaperlessBilling'''


# In[6]:


import re
pattern=re.compile('[a-zA-Z]+')
col_X = pattern.findall(text)
col_X


# ※ 학습 및 평가 데이터 세트 분할비는 7:3으로 하시오.  
# ※ seed는 123으로 고정하시오.  

# In[7]:


from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score


# In[8]:


seed = 123


# In[9]:


X=df3[col_X].copy()
y=df3['Churn'].copy()


# In[10]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=seed)


# ※ 범주형 변수의 범주가 "Yes"인 경우 1로, "No"인 경우 0으로 치환하여 분석하시오.  
# ※ 범주형 변수에서 "Yes"와 "No"가 아닌 나머지 범주는 -1로 치환하시오.  

# - 데이터 타입이 제대로 읽혔는 지 확인

# In[11]:


X_train.info()


# In[12]:


X_train.head()


# In[16]:


def cate2int(data):
    _df = data.select_dtypes(exclude='number').copy()
    _colname=data.select_dtypes(exclude='number').columns
    data[_colname] = _df[_colname].applymap(lambda x: 1 if x=='Yes' else (0 if x=='No' else -1)) 
    return data


# In[19]:


# 위에 람다식이랑 같음
def groups(x):
    if x=='Yes':
        return 1
    elif x=='No':
        return 0
    else:
        return -1
df[col_service].applymap(lambda x: groups(x))
df[col_service].applymap(groups) #이렇게 해줘도 됨


# In[18]:


X_train=cate2int(X_train).copy()
X_test=cate2int(X_test).copy()


# ※ 정규화는 Min-Max 정규화를 실시하며 모든 변수를 대상으로 하시오.  
# ※ 정답은 반올림하여 소수점 둘째 자리까지 출력하시오.  
# (정답 예시: 0.12)

# In[87]:


scaler_mm = MinMaxScaler()


# In[88]:


X_train=scaler_mm.fit_transform(X_train)


# In[89]:


X_test=scaler_mm.transform(X_test)


# In[90]:


model_lr = LogisticRegression(random_state = seed)
model_lr.fit(X = X_train,
             y = y_train)


# In[91]:


y_pred=model_lr.predict(X_test)


# In[97]:


from sklearn.metrics import confusion_matrix
confusion_matrix(y_test, y_pred)


# Q. 재현율(민감도)를 구하라

# In[105]:


279/(347+279)


# Q. f1 구하라

# In[95]:


round(f1_score(y_test, y_pred, pos_label='Yes'),2)


# In[103]:


from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))


# ### A3. 0.55
